var client = require('redis')
                .createClient(6379, 'redisuniandes2018-001.t5sapj.0001.use2.cache.amazonaws.com');
var aws = require('aws-sdk');                

exports.handler = (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
    // TODO implement
    
    aws.config.update({region: 'us-east-1'});
    
     client.subscribe('temperature');
      client.on("message", function (channel, message) {
        if(parseInt(message.toString())> 40){	   	   
        	   // Create sendEmail params 
          var params = {
            Destination: { /* required */
              CcAddresses: [
              'aoshishinomorig@gmail.com',
              'gabrielcruzparra@yahoo.com.mx'
              ],
              ToAddresses: [
                'aoshishinomorig@gmail.com',
                'gabrielcruzparra@yahoo.com.mx'
              ]
            },
          Message: { /* required */
          Body: { /* required */
            Html: {
              Charset: "UTF-8",
              Data: "<h2>Warning</h2>"
            },
            Text: {
              Charset: "UTF-8",
              Data: "datos sobrepasan el umbral de 40 - Dato: "+message.toString()
            }
        },
        Subject: {
          Charset: 'UTF-8',
          Data: 'Advertencia de sobrepaso del umbral'
        }
      },
        Source: 'aoshishinomorig@gmail.com', /* required */
        ReplyToAddresses: [
          'aoshishinomorig@gmail.com'
        /* more items */
        ],
      };       

  // Create the promise and SES service object
  var sendPromise = new aws.SES({apiVersion: '2010-12-01'}).sendEmail(params).promise();

  // Handle promise's fulfilled/rejected states
  sendPromise.then(
    function(data) {
      console.log(data.MessageId);
      }).catch(
        function(err) {
        console.error(err, err.stack);
      });    
        	   
    }  	 
                
});
      
      client = require('redis')
                .createClient(6379, 'redisuniandes2018-001.t5sapj.0001.use2.cache.amazonaws.com');
                
     client.subscribe('light');
      client.on("message", function (channel, message) {
        	   
        if(parseInt(message.toString())> 50){	   
        	   // Create sendEmail params 
          var params = {
            Destination: { /* required */
              CcAddresses: [
              'aoshishinomorig@gmail.com',
              'gabrielcruzparra@yahoo.com.mx'
              ],
              ToAddresses: [
                'aoshishinomorig@gmail.com',
                'gabrielcruzparra@yahoo.com.mx'
              ]
            },
        Message: { /* required */
        Body: { /* required */
          Html: {
            Charset: "UTF-8",
            Data: "<h2>Warning</h2>"
          },
          Text: {
            Charset: "UTF-8",
            Data: "datos sobrepasan el umbral de 50 - Dato: "+message.toString()
          }
        },
        Subject: {
          Charset: 'UTF-8',
          Data: 'Advertencia de sobrepaso del umbral'
        }
      },
        Source: 'aoshishinomorig@gmail.com', /* required */
        ReplyToAddresses: [
          'aoshishinomorig@gmail.com'
        /* more items */
        ],
      };       

  // Create the promise and SES service object
  var sendPromise = new aws.SES({apiVersion: '2010-12-01'}).sendEmail(params).promise();

  // Handle promise's fulfilled/rejected states
  sendPromise.then(
    function(data) {
      console.log(data.MessageId);
      }).catch(
        function(err) {
        console.error(err, err.stack);
      });    
        	   
    }   	 
                
});        
       
       
      client =require('redis')
                .createClient(6379, 'redisuniandes2018-001.t5sapj.0001.use2.cache.amazonaws.com');
                
     client.subscribe('peso');
      client.on("message", function (channel, message) {
        if(parseInt(message.toString())> 30){	   	   
        	   // Create sendEmail params 
        var params = {
          Destination: { /* required */
            CcAddresses: [
              'aoshishinomorig@gmail.com',
              'gabrielcruzparra@yahoo.com.mx'
            ],
            ToAddresses: [
              'aoshishinomorig@gmail.com',
              'gabrielcruzparra@yahoo.com.mx'
            
          ]
        },
        Message: { /* required */
        Body: { /* required */
          Html: {
            Charset: "UTF-8",
            Data: "<h2>Warning</h2>"
          },
          Text: {
            Charset: "UTF-8",
            Data: "datos sobrepasan el umbral de 30"+message.toString()
          }
        },
        Subject: {
          Charset: 'UTF-8',
          Data: 'Advertencia de sobrepaso del umbral'
        }
      },
        Source: 'aoshishinomorig@gmail.com', /* required */
        ReplyToAddresses: [
          'aoshishinomorig@gmail.com'
        /* more items */
        ],
      };       

  // Create the promise and SES service object
  var sendPromise = new aws.SES({apiVersion: '2010-12-01'}).sendEmail(params).promise();

  // Handle promise's fulfilled/rejected states
  sendPromise.then(
    function(data) {
      console.log(data.MessageId);
      }).catch(
        function(err) {
        console.error(err, err.stack);
      });    
        	   
  }    	 
                
});          
        
    console.log('Finalizando');  
    
    
    callback(null, 'Hello from Lambda');
};